export const faqs = [
	{
		id: 1,
		question: 'Is QTify free to use?',
		answer: 'Yes, you can use QTify for free.',
	},
	{
		id: 1,
		question: 'Can I download and listen to songs offline?',
		answer:
			"Sorry, unfortunately we don't provide the service to download any songs.",
	},
];
