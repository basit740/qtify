import TopBar from '../components/Topbar';

const Header = () => {
	return (
		<header>
			<TopBar />
		</header>
	);
};

export default Header;
